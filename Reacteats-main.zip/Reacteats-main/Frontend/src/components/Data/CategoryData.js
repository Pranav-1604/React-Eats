export const categories = [
  { text: "All", name: "All Items", status: "1" },
  { text: "Pizza", name: "Pizza", status: "0" },
  { text: "Chicken", name: "Chicken", status: "0" },
  { text: "Momos", name: "Momos", status: "0" },
  { text: "Rolls", name: "Rolls", status: "0" },
  { text: "Burgers", name: "Burgers", status: "0" },
  { text: "Desserts", name: "Desserts", status: "0" },
  { text: "Drinks", name: "Drinks", status: "0" }
]