export default function Loader() {
  return (
    <div className='loading centered'>
      <img src='./images/loader.gif' height="50px" />Loading...
    </div>
  )
}